libtoolize
aclocal
automake --add-missing
autoconf
autoheader
